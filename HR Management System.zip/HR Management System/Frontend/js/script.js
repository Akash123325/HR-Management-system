const totalEmployees = 50;
const attendanceToday = Math.floor(Math.random() * totalEmployees);
const payrollProcessed = Math.floor(Math.random() * totalEmployees);

function updateDashboard() {
    document.getElementById('total-employees').innerText = totalEmployees;
    document.getElementById('attendance-today').innerText = `${attendanceToday} Present`;
    document.getElementById('payroll-processed').innerText = `${payrollProcessed} Employees`;
    
    const activityList = document.getElementById('activity-list');
    activityList.innerHTML = ''; 
    activityList.innerHTML += `<li class="list-group-item">Employee Akash Singh checked in.</li>`;
    activityList.innerHTML += `<li class="list-group-item">Payroll processed for 20 employees.</li>`;
}

document.addEventListener('DOMContentLoaded', updateDashboard);

// Example: Fetching employee data from the backend
async function fetchEmployees() {
    try {
        const response = await fetch('http://127.0.0.1:8000/api/employees/', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                // Include authorization token if required
                'Authorization': 'Bearer ' + localStorage.getItem('token'),  // JWT token
            }
        });

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        const data = await response.json();
        console.log(data); // Handle your data (e.g., display it on the UI)
    } catch (error) {
        console.error('There was a problem with the fetch operation:', error);
    }
}

// Call the function to fetch employees when needed
fetchEmployees();

async function registerUser(userData) {
    try {
        const response = await fetch('http://127.0.0.1:8000/api/register/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(userData), // Convert data to JSON string
        });

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        const data = await response.json();
        console.log(data); // Handle successful registration
    } catch (error) {
        console.error('There was a problem with the registration:', error);
    }
}

// Example user data to register
const userData = {
    username: 'testuser',
    password: 'password123',
    // other fields as necessary
};

// Call the function to register the user
registerUser(userData);

function displayEmployees(employees) {
    const employeeList = document.getElementById('employee-list'); // Assuming you have a <div> for listing employees
    employeeList.innerHTML = ''; // Clear existing content

    employees.forEach(employee => {
        const listItem = document.createElement('li');
        listItem.textContent = `${employee.name} - ${employee.job_role}`;
        employeeList.appendChild(listItem);
    });
}

// Modify the fetchEmployees function to call displayEmployees
async function fetchEmployees() {
    // ...fetch logic
    const data = await response.json();
    displayEmployees(data); // Display the fetched employee data
}

async function loginUser(credentials) {
    const response = await fetch('http://127.0.0.1:8000/api/token/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(credentials),
    });

    if (response.ok) {
        const data = await response.json();
        localStorage.setItem('token', data.access); // Store the JWT token
        // Redirect or fetch protected resources
    } else {
        // Handle login failure
    }
}



