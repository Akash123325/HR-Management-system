from django.db import models
from django.utils import timezone

# Create your models here.
class Employee(models.Model):
    SALARY_TYPE_CHOICES = [
        ('fixed', 'Fixed Salary'),
        ('hourly', 'Hourly Rate'),
        ('commission', 'Commission Based'),
    ]

    name = models.CharField(max_length=100)
    contact_details = models.CharField(max_length=255)
    job_role = models.CharField(max_length=100)
    salary = models.DecimalField(max_digits=10, decimal_places=2)
    performance_history = models.TextField(blank=True, null=True)

    salary_type = models.CharField(max_length=10, choices=SALARY_TYPE_CHOICES, default='fixed')
    hourly_rate = models.DecimalField(max_digits=5, decimal_places=2, blank=True, null=True)  
    commission_rate = models.DecimalField(max_digits=5, decimal_places=2, blank=True, null=True)  
    def __str__(self):
        return self.name

class Document(models.Model):
    employee = models.ForeignKey(Employee, related_name='documents', on_delete=models.CASCADE)
    document_name = models.CharField(max_length=100)
    document_file = models.FileField(upload_to='employee_documents/')

    def __str__(self):
        return f"{self.document_name} - {self.employee.name}"
    
class Attendance(models.Model):
    employee = models.ForeignKey(Employee, related_name='attendance_records', on_delete=models.CASCADE)
    checkin_time = models.DateTimeField()
    checkout_time = models.DateTimeField(blank=True, null=True)
    location = models.CharField(max_length=255)

    def calculate_worked_hours(self):
        if self.checkout_time:
            duration = self.checkout_time - self.checkin_time
            return duration.total_seconds() / 3600   #converting into hours
        return 0
    
    def __str__(self):
        return f"Attendace of {self.employee.name} on {self.checkin_time.date()}"
    
class Leave(models.Model):
    Leave_TYPES = [
        ('vacation', 'Vacation'),
        ('sick', 'Sick Leave'),
        ('personal', 'Personal Leave'),
    ]

    employee = models.ForeignKey(Employee, related_name="leave_records", on_delete=models.CASCADE)
    leave_type = models.CharField(max_length=20, choices=Leave_TYPES)
    start_date = models.DateField()
    end_date = models.DateField()
    reason = models.TextField(blank=True)

    def __str__(self):
        return f"{self.leave_type.capitalize()} for {self.employee.name} from {self.start_date} to {self.end_date}"
    
class Overtime(models.Model):
    employee = models.ForeignKey(Employee, related_name="overtime_records", on_delete=models.CASCADE)
    date = models.DateField()
    hours_worked = models.DecimalField(max_digits=5, decimal_places=2)
    approved = models.BooleanField(default=False)

    def __str__(self):
        return f"Overtime for {self.employee.name} on {self.date}"

class Sales(models.Model):
    employee = models.ForeignKey(Employee, related_name='sales_records', on_delete=models.CASCADE)
    sales_amount = models.DecimalField(max_digits=10, decimal_places=2)  # Amount of sales made
    date = models.DateField()

    def __str__(self):
        return f"Sales by {self.employee.name} on {self.date}: {self.sales_amount}"

    
class Payroll(models.Model):
    employee = models.ForeignKey(Employee, related_name='payroll_records', on_delete=models.CASCADE)
    basic_salary = models.DecimalField(max_digits=10, decimal_places=2)  
    overtime_payment = models.DecimalField(max_digits=10, decimal_places=2, default=0)  
    bonus = models.DecimalField(max_digits=10, decimal_places=2, default=0)  
    deductions = models.DecimalField(max_digits=10, decimal_places=2, default=0)  
    total_salary = models.DecimalField(max_digits=10, decimal_places=2, default=0)  
    payment_date = models.DateField(auto_now_add=True)


    def calculate_total_salary(self):
        if self.employee.salary_type == 'fixed':
            self.total_salary = (self.basic_salary + self.overtime_payment + self.bonus) - self.deductions
        elif self.employee.salary_type == 'hourly':
            hours_worked = Attendance.objects.filter(employee=self.employee).aggregate(sum('worked_hours'))['worked_hours__sum']
            self.total_salary = (self.employee.hourly_rate * hours_worked + self.overtime_payment + self.bonus) - self.deductions
        elif self.employee.salary_type == 'commission':
            # Logic for commission based salary
            commission = Sales.objects.filter(employee=self.employee).aggregate(sum('sales_amount'))['sales_amount__sum'] * self.employee.commission_rate
            self.total_salary = (commission + self.overtime_payment + self.bonus) - self.deductions
        return self.total_salary
    
    def generate_payslip(self):
        payslip = f"""
        Payslip for {self.employee.name}
        Date: {self.payment_date}
        Basic Salary: {self.basic_salary}
        Overtime Payment: {self.overtime_payment}
        Bonus: {self.bonus}
        Deductions: {self.deductions}
        Total Salary: {self.total_salary}
        """
        return payslip



    def __str__(self):
        return f"Payroll for {self.employee.name} on {self.payment_date}"
