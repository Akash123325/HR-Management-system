from rest_framework import serializers
from .models import *
from django.contrib.auth.models import User

class UserRegistrationSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, required=True)

    class Meta:
        model = User
        fields = ['username', 'email', 'password']

    def create(self, validated_data):
        user = User.objects.create_user(
            username=validated_data['username'],
            email=validated_data['email'],
            password=validated_data['password']
        )
        return user


class DocumentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Document
        fields = ['id', 'document_name', 'document_file', 'employee']

class EmployeeSerializer(serializers.ModelSerializer):
    documents = DocumentSerializer(many=True, read_only=True)

    class Meta:
        model = Employee
        fields = ['id', 'name', 'contact_details', 'job_role', 'salary', 'performance_history', 'documents']

class AttendanceSerializer(serializers.ModelSerializer):
    worked_hours = serializers.SerializerMethodField()

    class Meta:
        model = Attendance
        fields = ['id', 'employee', 'checkin_time', 'checkout_time', 'location', 'worked_hours']

    def get_worked_hours(self, obj):
        return obj.calculate_worked_hours()

class LeaveSerializer(serializers.ModelSerializer):
    class Meta:
        model = Leave
        fields = ['id', 'employee', 'leave_type', 'start_date', 'end_date', 'reason']

class OvertimeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Overtime
        fields = ['id', 'employee', 'date', 'hours_worked', 'approved']

class SalesSerializer(serializers.ModelSerializer):
    class Meta:
        model = Sales
        fields = ['id', 'employee', 'sales_amount', 'date']



class PayrollSerializer(serializers.ModelSerializer):
    total_salary = serializers.SerializerMethodField()

    class Meta:
        model = Payroll
        fields = ['id', 'employee', 'basic_salary', 'overtime_payment', 'bonus', 'deductions', 'total_salary', 'payment_date']

    def get_total_salary(self, obj):
        return obj.calculate_total_salary()
